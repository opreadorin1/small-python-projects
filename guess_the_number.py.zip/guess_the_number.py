# Importing the "randint" functon that will help us generate a random number.
# Importign our "exit" function that will help end the script when we want to.
from random import randint
from sys import exit

# ======================= Difficulty Functions ======================= #

# Here we define 4 function that will represent the difficulties of the game.

# Normal Difficulty - This function will generated a number that the user has
# to guess. If he can guess the number, he'll win, if not, he'll lose.
# No matter the result, after the guessing, the user is asked if he wants to
# try again. If yes, the "start()" function will be called again, so the game
# will start once more. If no, then the game will just end.
def normal_difficulty():

    print "You chose the normal difficulty. Guess a number from 1 to 5!"

    # Variable containing a random number from 1 to 5.
    generated_number = (randint(1,5))

    # We use this variable to store the input of the user. We use int() to transform
    # the input of the user into an integer, and inside the input we use raw_input
    # to let the user insert a number.
    user_number = int(raw_input("> "))

    # Here we check to see if the number inserted by the user is equal the to generated number.
    # If yes, the user wins. If not, the user loses.
    if user_number == generated_number:
        print "You won! Congratulations!"

        # Here we ask the user if he wants to try again.
        print "Want to try again?"
        # We store the answer into a variable called "choice"
        choice = raw_input("> ")

        # And here we create an if/elif/else statement to check the answer.
        # If the answer is yes, the "start()" function is called again and the game will run.
        # If the answer is no, then the script stops.
        if choice == "yes" or choice == "y":
            start()
        elif choice == "no" or choice == "n":
            exit()
        else:
            print "I don't understand what you want."
            exit()
    else:
        print "You lost! I'm sorry!"

        print "Want to try again?"

        choice = raw_input("> ")

        if choice == "yes" or choice == "y":
            start()
        elif choice == "no" or choice == "n":
            exit()
        else:
            print "I don't understand what you want."
            exit()




# Medium Difficulty - This function will generated a number that the user has
# to guess. If he can guess the number, he'll win, if not, he'll lose.
# No matter the result, after the guessing, the user is asked if he wants to
# try again. If yes, the "start()" function will be called again, so the game
# will start once more. If no, then the game will just end.
def medium_difficulty():

    print "You chose the medium difficulty. Guess a number from 1 to 10!"

    # Variable containing a random number from 1 to 10.
    generated_number = (randint(1,10))

    # We use this variable to store the input of the user. We use int() to transform
    # the input of the user into an integer, and inside the input we use raw_input
    # to let the user insert a number.
    user_number = int(raw_input("> "))

    # Here we check to see if the number inserted by the user is equal the to generated number.
    # If yes, the user wins. If not, the user loses.
    if user_number == generated_number:
        print "You won! Congratulations!"

        # Here we ask the user if he wants to try again.
        print "Want to try again?"

        # We store the answer into a variable called "choice"
        choice = raw_input("> ")

        # And here we create an if/elif/else statement to check the answer.
        # If the answer is yes, the "start()" function is called again and the game will run.
        # If the answer is no, then the script stops.
        if choice == "yes" or choice == "y":
            start()
        elif choice == "no" or choice == "n":
            exit()
        else:
            print "I don't understand what you want."
            exit()
    else:
        print "You lost! I'm sorry!"

        print "Want to try again?"

        choice = raw_input("> ")

        if choice == "yes" or choice == "y":
            start()
        elif choice == "no" or choice == "n":
            exit()
        else:
            print "I don't understand what you want."
            exit()




# Hard Difficulty - This function will generated a number that the user has
# to guess. If he can guess the number, he'll win, if not, he'll lose.
# No matter the result, after the guessing, the user is asked if he wants to
# try again. If yes, the "start()" function will be called again, so the game
# will start once more. If no, then the game will just end.
def hard_difficulty():

    print "You chose the hard difficulty. Guess a number from 1 to 15!"

    # Variable containing a random number from 1 to 15.
    generated_number = (randint(1,15))

    # We use this variable to store the input of the user. We use int() to transform
    # the input of the user into an integer, and inside the input we use raw_input
    # to let the user insert a number.
    user_number = int(raw_input("> "))

    # Here we check to see if the number inserted by the user is equal the to generated number.
    # If yes, the user wins. If not, the user loses.
    if user_number == generated_number:
        print "You won! Congratulations!"

        # Here we ask the user if he wants to try again.
        print "Want to try again?"

        # We store the answer into a variable called "choice"
        choice = raw_input("> ")

        # And here we create an if/elif/else statement to check the answer.
        # If the answer is yes, the "start()" function is called again and the game will run.
        # If the answer is no, then the script stops.
        if choice == "yes" or choice == "y":
            start()
        elif choice == "no" or choice == "n":
            exit()
        else:
            print "I don't understand what you want."
            exit()
    else:
        print "You lost! I'm sorry!"

        print "Want to try again?"

        choice = raw_input("> ")

        if choice == "yes" or choice == "y":
            start()
        elif choice == "no" or choice == "n":
            exit()
        else:
            print "I don't understand what you want."
            exit()



# Very Hard Difficulty - This function will generated a number that the user has
# to guess. If he can guess the number, he'll win, if not, he'll lose.
# No matter the result, after the guessing, the user is asked if he wants to
# try again. If yes, the "start()" function will be called again, so the game
# will start once more. If no, then the game will just end.
def very_hard_difficulty():
    print "You chose the very hard difficulty. Guess a number from 1 to 20!"

    # Variable containing a random number from 1 to 20.
    generated_number = (randint(1,20))

    # We use this variable to store the input of the user. We use int() to transform
    # the input of the user into an integer, and inside the input we use raw_input
    # to let the user insert a number.
    user_number = int(raw_input("> "))

    # Here we check to see if the number inserted by the user is equal the to generated number.
    # If yes, the user wins. If not, the user loses.
    if user_number == generated_number:
        print "You won! Congratulations!"

        # Here we ask the user if he wants to try again.
        print "Want to try again?"

        # We store the answer into a variable called "choice"
        choice = raw_input("> ")

        # And here we create an if/elif/else statement to check the answer.
        # If the answer is yes, the "start()" function is called again and the game will run.
        # If the answer is no, then the script stops.
        if choice == "yes" or choice == "y":
            start()
        elif choice == "no" or choice == "n":
            exit()
        else:
            print "I don't understand what you want."
            exit()
    else:
        print "You lost! I'm sorry!"

        print "Want to try again?"

        choice = raw_input("> ")

        if choice == "yes" or choice == "y":
            start()
        elif choice == "no" or choice == "n":
            exit()
        else:
            print "I don't understand what you want."
            exit()
# ======================= End of the Difficulty Functions ======================= #





# # ======================= Start of the main function  ======================= #

# Here we define a function called "start", containing all the details about how the game works,
# and all the details about the 4 difficulties of the game. Inside this function we have a raw_input
# lets the user chose his difficulty. Based on the user's answer, a certain fucntion from the ones above
# will run, and the user will have to guess a random number.
def start():
    # Printint the introduction
    print """

    Hello and welcome to the 'Guess the number' script. This is a very short and straight foward game.

    The script will generate a random number, and you will have to guess what number the script generated.
    If you guess, then you'll win. If not, then you lose.

    This version of the script is and will remain a very short version. It will be small and straight foward.

    In the future some extended version may be created, that will contain more features.

    Before starting, you'll have to chose how difficult you want the game to be:

    1. Normal - numbers from 1 to 5 (including)

    2. Medium - numbers from 1 to 10 (inculding)

    3. Hard - numbers from 1 to 15 (including)

    4. Very hard - numbers from 1 to 20 (including)

    So, what difficulty will you choose?

    """
    # Here we create a variable tht will let the user type in the version of the script he
    # wants to play.
    script_version = raw_input("> ")

    # If/elif/else statements, that will check the answer of the user and will call
    # the needed function based on that answer. If the user does not write a valid answer
    # then the script will just stop.
    if script_version == "1" or script_version == "normal":
        normal_difficulty()
    elif script_version == "2" or script_version == "medium":
        medium_difficulty()
    elif script_version == "3" or script_version == "hard":
        hard_difficulty()
    elif script_version == "4" or script_version == "very hard":
        very_hard_difficulty()
    else:
        print "I don't understand what you're trying to say!"
        exit()

# ======================= End of the main function ======================= #



# Here is the beginning of the game. We call the "start" function which is the
# main function of the game, Everytime this function is called, the game will start.
start()
