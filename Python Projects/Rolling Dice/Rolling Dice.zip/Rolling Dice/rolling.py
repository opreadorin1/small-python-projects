# Here we import the randint function that will allow us to randmly generate numbers from 1 to 6
# Then we import the "exit()" function to be able to get out of the game whenever we want.
from random import randint
from sys import exit

# Here we define 5 variables storing random numbers from one to 6. This way the user can chose
# how many dices will be roled. Each function contains a number of "print" methods that will
# print a random number of numbers from 1 to 6
def one_dice():
    print "\nFirst dice is %d \n" %  (randint(1,6))

def two_dice():
    print "\nFirst dice is %d \n" % (randint(1,6))
    print "Second dice is %d \n" % (randint(1,6))

def three_dice():
    print "\nFirst dice is %d \n" % (randint(1,6))
    print "Second dice is %d \n" % (randint(1,6))
    print "Third dice is %d \n" % (randint(1,6))

def four_dice():
    print "\nFirst dice is %d \n" % (randint(1,6))
    print "Second dice is %d \n" % (randint(1,6))
    print "Third dice is %d \n" % (randint(1,6))
    print "Forth dice is %d \n" % (randint(1,6))

def five_dice():
    print "\nFirst dice is %d \n" % (randint(1,6))
    print "Second dice is %d \n" % (randint(1,6))
    print "Third dice is %d \n" % (randint(1,6))
    print "Forth dice is %d \n" % (randint(1,6))
    print "Fifth dice is %d \n" % (randint(1,6))


# Here we define a general function called "how_many" so we can use it whenever the user
# wants to "play" again. This is done in order to avoid long and unnecessary code.
def how_many():
    # First, we ask the user how many dices he wants to roll. This way, depending on the
    # answer, we can use one of the five functions above to give the user as many
    # dices as he wants. Notice that we also wrote "max 5" so the user knows he can
    # only use 5 dices at the time.
    print "\nSo, how many dices do you want to roll? Max 5!"

    # Here we define a variable called "choice" that will store the answer of the user
    choice = raw_input("> ")

    # And here is the most improtant point of this function. Each "if" and "elif" statement
    # will check the "choice" variable to see the answer of the user. Depending on that
    # answer the if statement will run a certain function or will start the game again.
    if choice == "1" or choice == "one":
        one_dice()
    elif choice == "2" or choice == "two":
        two_dice()
    elif choice == "3" or choice == "three":
        three_dice()
    elif choice == "4" or choice == "four":
        four_dice()
    elif choice == "5" or choice == "five":
        five_dice()
    else:
        print "I don't understand what you're trying to say. Start again! \n"
        start()



# Here we define the start function
def start():
    # We print two strings that will explain to the user what this script is doing.
    print "\nWelcome to the 'Dice rolling simulator'. This is a very simple text-based dice rolling simulator."
    print "All you have to do is tell me if you want to roll one dice or two, and when you are ready to do it."

    # Here we ask the user if he's ready to start the script, and we store the answer into
    # the variable bellow, called "ready".
    print "Ok, are you ready?\n"

    ready = raw_input("> ")

    # Here we use an if/else statement to check if the user wants to start the script or not. If yes
    # then we call the "how_many()" function and everything starts. If not, then then the script stops.
    # if none of the answers above are provided, the script will just run again.
    if ready == "yes" or ready == "y":
        how_many()
    elif ready == "no" or ready == "n":
        print "Well then, run this script again when you are ready."
        exit()
    else:
        print "I don't understand what you are trying to say. Start again!"
        start()

    # Here is one of the most important parts of the script. Here we ask the user if he wants
    # to do everything again. We then store the user's answer into a variable called "choice".
    print "Want to keep trying?\n"

    choice = raw_input(">")

    if choice == "yes" or "y":
        print "\nIf you want to stop the script, press ctrl + c!"
    elif choice == "no" or "n":
        print "Okay, have a nice day!"
    else:
        print "I don't understand what you're trying to say!"
        start()

    # After that, we use a "while" function to check the answer of the user.
    # As long as the answer is "yes" or "y", the "how_many()" function will keep running.
    # The reason I used a "while" loop is because I did not want to ask the question
    # "want to keep trying" all the time, and just let the user play with the dices.
    # I created an infinite loop, and the user can use the dice as many times as he wants
    # and whenever he wants to stop, all he has to do is press ctrl + n to interrupt the script.
    while choice == "yes" or choice == "y":
        how_many()
start()
